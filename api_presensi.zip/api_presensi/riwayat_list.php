<?php
include "koneksi.php";

$query = mysqli_query($koneksi, "SELECT * FROM tb_kehadiran ORDER BY id DESC");

while ($row = mysqli_fetch_assoc($query)) {
    echo $row['waktu'] . " | NIS: " . $row['nis'] . " | Nama: " . $row['nama'] . "\n";
}
?>