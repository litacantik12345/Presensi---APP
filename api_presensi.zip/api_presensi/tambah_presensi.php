<?php

include "koneksi.php";

$nis = $_POST['nis'];
$nama = $_POST['nama'];
$foto = $_POST['foto'];

$query = "INSERT INTO tb_kehadiran (nis, nama, foto)
          VALUES ('$nis', '$nama', '$foto')";

if (mysqli_query($koneksi, $query)) {
    echo "success";
} else {
    echo "error";
}

?>