<?php
$koneksi = mysqli_connect("localhost", "root", "", "db_presensi");

if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

$query = mysqli_query($koneksi, "SELECT * FROM tb_kehadiran ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Admin Presensi</title>

    <style>
        body {
            font-family: Arial;
            background: #f2f2f2;
            margin: 0;
            padding: 20px;
        }

        h1 {
            text-align: center;
        }

        .box {
            background: white;
            padding: 20px;
            border-radius: 10px;
            max-width: 1000px;
            margin: auto;
        }

        .tombol {
            padding: 10px 15px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            margin-bottom: 15px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: center;
        }

        th {
            background: #3949ab;
            color: white;
        }
    </style>
</head>

<body>

<div class="box">

    <h1>Dashboard Admin Presensi</h1>

    <button class="tombol" onclick="window.print()">
        Cetak
    </button>

    <a href="export_excel.php">
        <button class="tombol">
            Ekspor Excel
        </button>
    </a>

    <table>
        <tr>
            <th>ID</th>
            <th>Waktu</th>
            <th>NIS</th>
            <th>Nama</th>
            <th>Foto</th>
        </tr>

        <?php while ($data = mysqli_fetch_assoc($query)) { ?>

        <tr>
            <td>
                <?php echo $data['id']; ?>
            </td>

            <td>
                <?php echo $data['waktu']; ?>
            </td>

            <td>
                <?php echo $data['nis']; ?>
            </td>

            <td>
                <?php echo $data['nama']; ?>
            </td>

            <td>
                <?php echo $data['foto']; ?>
            </td>
        </tr>

        <?php } ?>

    </table>

</div>

</body>
</html>