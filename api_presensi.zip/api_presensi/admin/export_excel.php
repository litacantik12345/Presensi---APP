<?php

$koneksi = mysqli_connect(
    "localhost",
    "root",
    "",
    "db_presensi"
);

if (!$koneksi) {
    die("Koneksi gagal");
}

header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=rekap_presensi.xls");

$query = mysqli_query(
    $koneksi,
    "SELECT * FROM tb_kehadiran ORDER BY id DESC"
);

?>

<table border="1">

<tr>
    <th>ID</th>
    <th>Waktu</th>
    <th>NIS</th>
    <th>Nama</th>
    <th>Foto</th>
</tr>

<?php while ($data = mysqli_fetch_assoc($query)) { ?>

<tr>
    <td><?php echo $data['id']; ?></td>
    <td><?php echo $data['waktu']; ?></td>
    <td><?php echo $data['nis']; ?></td>
    <td><?php echo $data['nama']; ?></td>
    <td><?php echo $data['foto']; ?></td>
</tr>

<?php } ?>

</table>