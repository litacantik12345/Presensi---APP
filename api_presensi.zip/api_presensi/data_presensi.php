<?php
include "koneksi.php";

header("Content-Type: text/plain; charset=utf-8");

$query = mysqli_query(
    $koneksi,
    "SELECT waktu, nis, nama FROM tb_kehadiran ORDER BY id DESC"
);

while ($row = mysqli_fetch_assoc($query)) {
    echo "Waktu: " . $row["waktu"]
       . " | NIS: " . $row["nis"]
       . " | Nama: " . $row["nama"] . "\n";
}
?>